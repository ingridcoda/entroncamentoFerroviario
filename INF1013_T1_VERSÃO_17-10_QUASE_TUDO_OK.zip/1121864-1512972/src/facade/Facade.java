package facade;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import domain.Ferrovia;
import domain.Sinal;
import domain.Trem;
import view.FerroviaFrame;


// TODO: CRIAR M�TODO DE DISPARO DE TRENS, COM L�GICA DE ESTADO DO SINAL E DO TREM.
public class Facade implements Observer{

	static Facade instancia = null;
	static ArrayList<Trem> trensD;
	static ArrayList<Trem> trensE;
	static Sinal sinalEsquerda;
	static Sinal sinalDireita;
	static Ferrovia f = new Ferrovia();

	private Facade() throws IOException{
		f.listaObserver.add(this);
		new FerroviaFrame();
		trensE = new ArrayList<Trem>();
		trensD = new ArrayList<Trem>();
		sinalEsquerda = new Sinal("esquerda");
		sinalDireita = new Sinal("direita");		
	}

	public static Facade getInstance() throws IOException{
		if(instancia == null){
			instancia = new Facade();
		}
		return instancia;
	}

	public static Trem CriaTrem(String direcao){

		return new Trem(direcao);

	}

	public static void CriaTremEsquerda(ActionEvent event, ArrayList<Point> trensViewEsquerda) {

		trensE.add(Facade.CriaTrem("esquerda"));
		Point ponto = new Point(0, 333);
		trensViewEsquerda.add(ponto);		

	}

	public static void CriaTremDireita(ActionEvent event, ArrayList<Point> trensViewDireita) {

		trensD.add(Facade.CriaTrem("direita"));
		Point ponto = new Point(1540, 460);
		trensViewDireita.add(ponto);		

	}

	public static void CriaSinal(String direcao) {
		new Sinal(direcao);
	}

	public static String VerificaSinalEsquerda() {
		return sinalEsquerda.getEstado().getClass().getSimpleName();
	}

	public static String VerificaSinalDireita() {
		return sinalDireita.getEstado().getClass().getSimpleName();
	}

	public static ArrayList<Point> GetTrensEsquerda(){

		ArrayList<Point> trensViewsE = new ArrayList<Point>();

		for(Trem t : trensE) {
			trensViewsE.add(new Point(t.getX(), t.getY()));
		}

		return trensViewsE;
	}

	public static ArrayList<Point> GetTrensDireita(){

		ArrayList<Point> trensViewsD = new ArrayList<Point>();

		for(Trem t : trensD) {
			trensViewsD.add(new Point(t.getX(), t.getY()));
		}

		return trensViewsD;
	}

	public static void AlteraSinalDireita() {

		if(Facade.VerificaSinalDireita().equals("Fechado")) {
			sinalDireita.getEstado().abrir(sinalDireita);
		} else {
			sinalDireita.getEstado().fechar(sinalDireita);
		}

	}

	public static void AlteraSinalEsquerda() {

		if(Facade.VerificaSinalEsquerda().equals("Fechado")) {
			sinalEsquerda.getEstado().abrir(sinalEsquerda);
		} else {
			sinalEsquerda.getEstado().fechar(sinalEsquerda);
		}		

	}

	public static Point AtualizaTrem(Point p1, Point p2, String direcao) {

		Point p = null;
		if(direcao.equals("esquerda")) {

			for(Trem t : trensE) {
				if(t.getX() == p1.x && t.getY() == p1.y) {
					t.setX(p2.x);
					t.setY(p2.y);
					p = new Point(t.getX(), t.getY());
				}
			}

		} else {
			for(Trem t : trensD) {
				if(t.getX() == p1.x && t.getY() == p1.y) {
					t.setX(p2.x);
					t.setY(p2.y);
					p = new Point(t.getX(), t.getY());
				}
			}
		}
		return p;

	}

	public static void RemoveTrem(Point p, String direcao) {

		if(direcao.equals("esquerda")) {
			trensE.remove(trensE.get(0));
		} else {
			trensD.remove(trensD.get(0));
		}
	}



	public static void EstaNoSensor(String acao, String direcao) {
		ArrayList<Sinal> sinaisObs = new ArrayList<Sinal>();
		if(acao.equals("entrada")) {
			if(direcao.equals("esquerda")) {
				if(Facade.VerificaSinalEsquerda().equals("Aberto") && Facade.VerificaSinalDireita().equals("Aberto")){
					System.out.println("entrada esquerda aberto");
					sinaisObs.clear();
					sinaisObs.add(sinalDireita);
					f.setSensorEntradaEsquerda(sinaisObs);	
				}
			} else {
				if(Facade.VerificaSinalDireita().equals("Aberto")&& Facade.VerificaSinalEsquerda().equals("Aberto")){
					System.out.println("entrada direita aberto");
					sinaisObs.clear();
					sinaisObs.add(sinalEsquerda);
					f.setSensorEntradaDireita(sinaisObs);
				}
			}
		} else {
			if(direcao.equals("esquerda")) {
				if(trensE.size() == 1){
					if(trensD.isEmpty()){
						System.out.println("saida esquerda vazio direita");
						sinaisObs.clear();
						sinaisObs.add(sinalDireita);
						f.setSensorSaidaEsquerda(sinaisObs);
					} else {
						System.out.println("saida esquerda alguem na direita");
						sinaisObs.clear();
						sinaisObs.add(sinalDireita);
						sinaisObs.add(sinalEsquerda);
						f.setSensorSaidaEsquerda(sinaisObs);
					}
				}

			} else {
				if(trensD.size() == 1){
					if(trensE.isEmpty()){
						System.out.println("saida direita vazio esquerda");
						sinaisObs.clear();
						sinaisObs.add(sinalEsquerda);
						f.setSensorSaidaDireita(sinaisObs);
					} else {
						System.out.println("saida direita alguem na esquerda");
						sinaisObs.clear();
						sinaisObs.add(sinalDireita);
						sinaisObs.add(sinalEsquerda);
						f.setSensorSaidaDireita(sinaisObs);
					}
				}
			}
		}

	}

	/* Observer */
	@Override
	public void update(Observable o, Object arg) {
		System.out.println("O observador foi notificado de uma modifica��o!");
		Sinal s = (Sinal) arg;
		if(s.getDirecao().equals("esquerda")) {
			Facade.AlteraSinalEsquerda();
		} else {
			Facade.AlteraSinalDireita();
		}		
	}
}
