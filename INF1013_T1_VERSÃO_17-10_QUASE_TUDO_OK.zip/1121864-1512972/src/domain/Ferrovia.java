package domain;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class Ferrovia extends Observable {
	
	private boolean sensorEntradaDireita;
	private boolean sensorSaidaDireita;
	private boolean sensorEntradaEsquerda;
	private boolean sensorSaidaEsquerda;
	public ArrayList<Observer> listaObserver = new ArrayList<Observer>();	

	public Ferrovia() {
		super();
		this.sensorEntradaDireita = false;
		this.sensorSaidaDireita = false;
		this.sensorEntradaEsquerda = false;
		this.sensorSaidaEsquerda = false;
	}
	
	public void setSensorEntradaDireita(Object obj) {
		this.sensorEntradaDireita = !sensorEntradaDireita;
		notifyObservers(obj);
	}
	
	public void setSensorSaidaDireita(Object obj) {
		this.sensorSaidaDireita = !sensorSaidaDireita;
		notifyObservers(obj);
	}
	
	public void setSensorEntradaEsquerda(Object obj) {
		this.sensorEntradaEsquerda = !sensorEntradaEsquerda;
		notifyObservers(obj);
	}
	
	public void setSensorSaidaEsquerda(Object obj) {
		this.sensorSaidaEsquerda = !sensorSaidaEsquerda;
		notifyObservers(obj);
	}
	
	/* Observer */
	@SuppressWarnings("unchecked")
	public void notifyObservers(Object obj){
		ArrayList<Sinal> sinais = (ArrayList<Sinal>) obj;
		System.out.println("Lista sinais observers : "+sinais.size());
		for(Observer obs: listaObserver){
			for(Sinal s: sinais){
				System.out.println(s.getClass().getSimpleName());
				obs.update(this, s);
			}
		}
	}

}
