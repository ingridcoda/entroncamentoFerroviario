package domain;

import controller.state.sinalState.Aberto;
import controller.state.sinalState.SinalState;

public class Sinal{

	private String direcao;

	private SinalState estado;
	
	public Sinal(String direcao) {
		this.direcao = direcao;
		this.estado = new Aberto();
	}

	public String getDirecao() {
		return direcao;
	}

	public void setDirecao(String dir) {
		this.direcao = dir;
	}

	public SinalState getEstado() {
		return estado;
	}

	public void setEstado(SinalState est) {
		this.estado = est;
	}
}
