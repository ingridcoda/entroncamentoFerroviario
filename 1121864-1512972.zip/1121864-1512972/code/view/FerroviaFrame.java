package view;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.Timer;

import controller.Facade;

@SuppressWarnings("serial")

public class FerroviaFrame extends JFrame implements ActionListener {

	public static FerroviaFrame instancia = null;
	private ArrayList<Point> trensD;
	private ArrayList<Point> trensE;
	private JButton btnStartDirLento;
	private JButton btnStartEsqLento;
	private JButton btnStartDirMedio;
	private JButton btnStartEsqMedio;
	private JButton btnStartDirRapido;
	private JButton btnStartEsqRapido;
	private Timer t;	

	private FerroviaFrame() throws IOException {	
		
		super();
		this.setSize(1575, 787);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setBackground(Color.WHITE);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Entroncamento Ferrovi�rio");		

		this.trensD = new ArrayList<Point>();
		this.trensE = new ArrayList<Point>();		

		this.btnStartEsqLento = new JButton("Esquerda - Lento");
		this.btnStartEsqLento.setBounds(230, 700, 150, 40);
		this.btnStartEsqLento.setVisible(true);
		this.add(btnStartEsqLento);
		this.btnStartEsqLento.addActionListener(this);
		
		this.btnStartDirLento = new JButton("Direita - Lento");
		this.btnStartDirLento.setBounds(420, 700, 150, 40);
		this.btnStartDirLento.setVisible(true);
		this.add(btnStartDirLento);
		this.btnStartDirLento.addActionListener(this);

		this.btnStartEsqMedio = new JButton("Esquerda - M�dio");
		this.btnStartEsqMedio.setBounds(610, 700, 150, 40);
		this.btnStartEsqMedio.setVisible(true);
		this.add(btnStartEsqMedio);
		this.btnStartEsqMedio.addActionListener(this);
		
		this.btnStartDirMedio = new JButton("Direita - M�dio");
		this.btnStartDirMedio.setBounds(800, 700, 150, 40);
		this.btnStartDirMedio.setVisible(true);
		this.add(btnStartDirMedio);
		this.btnStartDirMedio.addActionListener(this);		

		this.btnStartEsqRapido = new JButton("Esquerda - R�pido");
		this.btnStartEsqRapido.setBounds(990, 700, 150, 40);
		this.btnStartEsqRapido.setVisible(true);
		this.add(btnStartEsqRapido);
		this.btnStartEsqRapido.addActionListener(this);
		
		this.btnStartDirRapido = new JButton("Direita - R�pido");
		this.btnStartDirRapido.setBounds(1180, 700, 150, 40);
		this.btnStartDirRapido.setVisible(true);
		this.add(btnStartDirRapido);
		this.btnStartDirRapido.addActionListener(this);
		
		t = new Timer(0, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				redesenha();					
			}			
		});	
		
		this.getContentPane().add(FerroviaView.getInstance("Ferrovia.jpg"));
		this.setVisible(true);

	}

	///////////////////////// Singleton ///////////////////////////
	public static FerroviaFrame getInstance() throws IOException {		
		if(instancia == null) {
			instancia = new FerroviaFrame();
		} 
		
		return instancia;		
	}
	///////////////////////////////////////////////////////////////
	
	
	private void redesenha() {		
		this.repaint();		
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {	
		if(event.getSource() == btnStartDirLento) {
			
			Facade.CriaTremDireita(event, trensD);
			if(t.isRunning()) t.stop();
			t.setDelay(200);
			t.start();
			

		} else if(event.getSource() == btnStartEsqLento) {

			Facade.CriaTremEsquerda(event, trensE);
			if(t.isRunning()) t.stop();
			t.setDelay(200);
			t.start();
			
		} else if(event.getSource() == btnStartDirMedio) {
			
			Facade.CriaTremDireita(event, trensD);
			if(t.isRunning()) t.stop();
			t.setDelay(100);
			t.start();
			

		} else if(event.getSource() == btnStartEsqMedio) {

			Facade.CriaTremEsquerda(event, trensE);
			if(t.isRunning()) t.stop();
			t.setDelay(100);
			t.start();
			
		} else if(event.getSource() == btnStartDirRapido) {
			
			Facade.CriaTremDireita(event, trensD);
			if(t.isRunning()) t.stop();
			t.setDelay(50);
			t.start();
			

		} else if(event.getSource() == btnStartEsqRapido) {

			Facade.CriaTremEsquerda(event, trensE);
			if(t.isRunning()) t.stop();
			t.setDelay(50);
			t.start();
			
		}		
	}  
}

