package state;

import domain.Sinal;

public class Aberto extends SinalState {

	public void fechar(Sinal sinal) {
		sinal.setEstado(new Fechado());
	}
}
