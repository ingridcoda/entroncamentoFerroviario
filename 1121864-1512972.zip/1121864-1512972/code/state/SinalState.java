package state;

import domain.Sinal;

public abstract class SinalState {

	private Sinal sinal;

	public SinalState getEstadoInicial(Sinal sinal) {
		return estado();
	}

	public SinalState estado() {
		return sinal.getEstado();
	}

	public void abrir(Sinal sinal) {}

	public void fechar(Sinal sinal) {}

}
