package domain;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class Ferrovia extends Observable {

	private ArrayList<Trem> trensD;
	private ArrayList<Trem> trensE;
	private Sinal sinalEsquerda;
	private Sinal sinalDireita;
	private ArrayList<Observer> listaObserver = new ArrayList<Observer>();	
	public static Ferrovia instancia = null;

	private Ferrovia() {
		super();

		trensE = new ArrayList<Trem>();
		trensD = new ArrayList<Trem>();

		sinalEsquerda = new Sinal("esquerda");
		sinalDireita = new Sinal("direita");
	}
	

	///////////////////////// Singleton ///////////////////////////
	public static Ferrovia getInstance() throws IOException {		
		if(instancia == null){
			instancia = new Ferrovia();
		}

		return instancia;		
	}
	//////////////////////////////////////////////////////////////
	
	
	
	///////////////////////// Observer ///////////////////////////
	public ArrayList<Observer> getListaObserver() {
		return listaObserver;
	}

	@SuppressWarnings("unchecked")
	public void notifyObservers(Object obj) {		
		ArrayList<Sinal> sinais = (ArrayList<Sinal>) obj;

		for(Observer obs: listaObserver){

			for(Sinal s: sinais){
				obs.update(this, s);
			}

		}		
	}
	////////////////////////////////////////////////////////////////
	
	
	
	public void CriaTremEsquerda(ActionEvent event, ArrayList<Point> trensViewEsquerda) {
		trensE.add(new Trem("esquerda"));
		Point ponto = new Point(-30, 333);
		trensViewEsquerda.add(ponto);		
	}

	public void CriaTremDireita(ActionEvent event, ArrayList<Point> trensViewDireita) {		
		trensD.add(new Trem("direita"));
		Point ponto = new Point(1570, 460);
		trensViewDireita.add(ponto);		
	}

	public void CriaSinal(String direcao) {		
		new Sinal(direcao);			
	}

	public String VerificaSinalEsquerda() {		
		return sinalEsquerda.getEstado().getClass().getSimpleName();		
	}

	public String VerificaSinalDireita() {		
		return sinalDireita.getEstado().getClass().getSimpleName();		
	}

	public ArrayList<Point> GetTrensEsquerda() {
		ArrayList<Point> trensViewsE = new ArrayList<Point>();

		for(Trem t : trensE) {
			trensViewsE.add(new Point(t.getX(), t.getY()));
		}

		return trensViewsE;
	}

	public ArrayList<Point> GetTrensDireita() {
		ArrayList<Point> trensViewsD = new ArrayList<Point>();

		for(Trem t : trensD) {
			trensViewsD.add(new Point(t.getX(), t.getY()));
		}

		return trensViewsD;		
	}

	public void AlteraSinalDireita() {
		if(VerificaSinalDireita().equals("Fechado")) {
			sinalDireita.getEstado().abrir(sinalDireita);
		} else {
			sinalDireita.getEstado().fechar(sinalDireita);
		}
	}

	public void AlteraSinalEsquerda() {
		if(VerificaSinalEsquerda().equals("Fechado")) {
			sinalEsquerda.getEstado().abrir(sinalEsquerda);
		} else {
			sinalEsquerda.getEstado().fechar(sinalEsquerda);
		}
	}

	public boolean DistanciaMinima(Point p1, Point p2, String direcao) {		
		if(direcao.equals("direita")) 
			return ((p2.x - p1.x) <= -150);
		
		return ((p2.x - p1.x) >= 150);	
	}

	public Point AtualizaTrem(Point p1, Point p2, String direcao) {
		Point p = null;
		if(direcao.equals("esquerda")) {

			for(Trem t : trensE) {

				if(t.getX() == p1.x && t.getY() == p1.y) {
					t.setX(p2.x);
					t.setY(p2.y);
					p = new Point(t.getX(), t.getY());
				}

			}

		} else {

			for(Trem t : trensD) {

				if(t.getX() == p1.x && t.getY() == p1.y) {
					t.setX(p2.x);
					t.setY(p2.y);
					p = new Point(t.getX(), t.getY());
				}

			}

		}

		return p;
	}

	public void RemoveTrem(Point p, String direcao) {
		if(direcao.equals("esquerda")) {
			trensE.remove(trensE.get(0));
		} else {
			trensD.remove(trensD.get(0));
		}		
	}



	public void EstaNoSensor(String acao, String direcao) {		
		ArrayList<Sinal> sinaisObs = new ArrayList<Sinal>();

		if(acao.equals("entrada")) {

			if(direcao.equals("esquerda")) {

				if(VerificaSinalEsquerda().equals("Aberto") && VerificaSinalDireita().equals("Aberto")) {					
					sinaisObs.clear();
					sinaisObs.add(sinalDireita);
					notifyObservers(sinaisObs);						
				}

			} else {

				if(VerificaSinalDireita().equals("Aberto")&& VerificaSinalEsquerda().equals("Aberto")) {					
					sinaisObs.clear();
					sinaisObs.add(sinalEsquerda);
					notifyObservers(sinaisObs);					
				}

			}

		} else {

			if(direcao.equals("esquerda")) {

				if(trensE.size() == 1) {

					if(trensD.isEmpty()) {						
						sinaisObs.clear();
						sinaisObs.add(sinalDireita);
						notifyObservers(sinaisObs);						
					} else {						
						sinaisObs.clear();
						sinaisObs.add(sinalDireita);
						sinaisObs.add(sinalEsquerda);
						notifyObservers(sinaisObs);						
					}

				}

			} else {

				if(trensD.size() == 1) {

					if(trensE.isEmpty()) {						
						sinaisObs.clear();
						sinaisObs.add(sinalEsquerda);
						notifyObservers(sinaisObs);						
					} else {						
						sinaisObs.clear();
						sinaisObs.add(sinalDireita);
						sinaisObs.add(sinalEsquerda);
						notifyObservers(sinaisObs);						
					}

				}

			}
		}
	}

	
}



