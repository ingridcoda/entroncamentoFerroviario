package facade;

import java.io.IOException;

import view.FrameGeral;

public class Facade {
	
	public static void Start() throws IOException {
		new FrameGeral();
	}

}
