package facade;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;

import controller.FerroviaController;
import view.FerroviaFrame;
import view.TremView;

public class Facade {

	public static void Start() throws IOException {
		new FerroviaFrame();
	}

	public static void IniciaTrem(ActionEvent event, TremView trem, ArrayList<TremView> trens, int x, int y, int i) {
		//while(i < 100) {
			trem.setX(trem.getX() + i);
			new FerroviaController(trem, trens, trem.getX(), trem.getY()).actionPerformed(event);
			//i += i;
		//}
	}

}
