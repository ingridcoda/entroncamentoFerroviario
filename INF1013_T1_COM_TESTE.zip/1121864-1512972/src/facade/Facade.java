package facade;

import view.FrameGeral;

public class Facade {
	
	public static void Start() {
		new FrameGeral();
	}

}
