package view;

import java.awt.*;
import javax.swing.*;

@SuppressWarnings("serial")

public class FrameGeral extends JFrame{
	
	protected JPanel painel;
	public static FrameGeral instancia = null;
	
	public FrameGeral(){	
		super();
		this.setSize(1575, 787);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setBackground(Color.WHITE);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Entroncamento Ferrovi�rio");	
		this.setVisible(true);
		this.painel.add(new FerroviaView());
		this.painel.setVisible(true);
		this.painel.setBounds(0, 0, 1575, 787);
		
		this.getContentPane().add(painel);
		this.painel.repaint();
	}
	
	public static FrameGeral getInstance(){
		if(instancia == null){
			instancia = new FrameGeral();
		} 
		return instancia;
	}
}

