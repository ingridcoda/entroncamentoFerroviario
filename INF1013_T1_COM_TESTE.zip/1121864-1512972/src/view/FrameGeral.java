package view;

import java.awt.*;
import java.io.IOException;

import javax.swing.*;

@SuppressWarnings("serial")

public class FrameGeral extends JFrame{
	
	public static FrameGeral instancia = null;
	
	public FrameGeral() throws IOException{	
		super();
		this.setSize(1575, 787);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setBackground(Color.WHITE);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Entroncamento Ferrovi�rio");	
		this.getContentPane().add(new FerroviaView("Ferrovia.jpg"));
		this.setVisible(true);
		
	}
	
	public static FrameGeral getInstance() throws IOException{
		if(instancia == null){
			instancia = new FrameGeral();
		} 
		return instancia;
	}
}

