package view;


import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import java.io.IOException;


import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import javax.swing.JPanel;


@SuppressWarnings("serial")
public class FerroviaView extends JPanel{

	private Image img = null;
	
	public FerroviaView(String urlImg) throws IOException    {  

		this.img = ImageIO.read(new File(urlImg)); 

		this.setLayout(null);
		this.setBounds(0, 0, 1575, 787);
		this.setVisible(true);
		
	}

	@Override  
	public void paintComponent(Graphics g) {  
		
		super.paintComponent(g);        
		Graphics2D gr = (Graphics2D)g;  
		System.out.println("Entrei no paint de ferrovia");
		gr.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), null);
		
		
	}



}
