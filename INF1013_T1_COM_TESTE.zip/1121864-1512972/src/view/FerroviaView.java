package view;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class FerroviaView extends JPanel {
	
	 	Image background = new ImageIcon("D:/Eclipse/Projetos/a/src/view/Ferrovia.jpg").getImage();

		public FerroviaView(){	
			super();

			this.setBounds(0,0,1575,787);
		}
		
		
		public void paintComponent(Graphics g) {
		     super.paintComponent(g);
		     Graphics2D g2d = (Graphics2D) g;		    
		     g2d.drawImage(background, 0, 0, this);
		}
		
}
