package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class SinalView extends JPanel {
	
	private int x;
	private int y;
	private Color cor;
	
	public SinalView(Color cor, int x, int y) {
		this.x = x;
		this.y = y;
		this.cor = cor;
		this.setLayout(null);
		this.setBounds(0, 0, 30, 30);
	    this.setBackground(Color.BLACK);
		this.setLocation(this.x, this.y);		
		this.setVisible(true);
		System.out.println("Entrei no construtor de sinal");
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.BLACK);
		g2d.drawRect(x, y, 30, 30);		
		g2d.setColor(cor);
		g2d.fillOval(x, y, 30, 30);
		System.out.println("Entrei no paint de sinal");
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Color getCor() {
		return cor;
	}

	public void setCor(Color cor) {
		this.cor = cor;
	}
}
