package controller.state.tremState;

public class Andando extends TremState {

	public TremState timeout() {
		return null;
	}

	public void parar() {

	}

}
