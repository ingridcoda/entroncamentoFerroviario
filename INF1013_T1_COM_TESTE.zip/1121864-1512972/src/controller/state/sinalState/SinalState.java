package controller.state.sinalState;

import domain.Sinal;

public class SinalState {

	private Sinal sinal;

	public SinalState getEstadoInicial(Sinal sinal) {
		return null;
	}

	public SinalState estado() {
		return sinal.getEstado();
	}

	public void abrir() {
		
	}

	public void fechar() {

	}

}
