package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import domain.Ferrovia;

public class FerroviaController implements ActionListener{
	
	Ferrovia ferrovia;
	
	public FerroviaController(float x, float y) {

	}

	//click bot�o,  ver depois
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
