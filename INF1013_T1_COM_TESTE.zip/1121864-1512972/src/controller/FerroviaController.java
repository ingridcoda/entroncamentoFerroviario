package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Timer;

import domain.Ferrovia;
import view.TremView;

public class FerroviaController implements ActionListener{

	Ferrovia ferrovia;
	Timer timer;
	TremView trem;
	ArrayList<TremView> trens = new ArrayList<TremView>();
	int x, y;

	public FerroviaController(TremView trem, ArrayList<TremView> trens, int x, int y) {
		this.trem = trem;
		this.trens = trens;
		this.x = x;
		this.y = y;
	}

	@Override
	public void actionPerformed(ActionEvent event) {

		for(TremView t : trens) {
			timer = new Timer(1000, new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent event) {

					t.setX(x);
					t.setY(y);
					t.setLocation(t.getX(), t.getY());

					System.out.println(t.getLocation());
					t.repaint();
					trem = t;
				}


			});

			timer.start();

		}
		trem.repaint();
	}

}


