package teste;

import java.io.IOException;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) throws IOException {
		JFrame f = new JFrame();
		f.setVisible(true);
		f.setSize(1575, 787);
		f.getContentPane().add(new FundoBg("D:/Eclipse/Projetos/1121864-1512972/src/Ferrovia.jpg"));

	}

}

