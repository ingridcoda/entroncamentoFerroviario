import java.io.IOException;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) throws IOException {
		JFrame f = new JFrame();
		
		f.setSize(1575, 787);
		f.setVisible(true);

		f.getContentPane().add(new FundoBg("Ferrovia.jpg"));
		
	}

}

