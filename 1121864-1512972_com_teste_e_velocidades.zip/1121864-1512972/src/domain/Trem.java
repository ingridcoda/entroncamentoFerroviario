package domain;


public class Trem {

	private String direcao;
	
	private int x, y;

	private float velocidade;

	public Trem (String dir) {
		
		this.direcao = dir;
		
		if (this.direcao.equals("esquerda")) {			
			this.velocidade = 5;	
			this.x = 0;
			this.y = 333;			
		} else {			
			this.velocidade = -5;	
			this.x = 1540;
			this.y = 460;
		}

	}

	public String getDirecao() {
		return direcao;
	}

	public void setDirecao(String dir) {
		this.direcao = dir;
	}

	public float getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(float vel) {
		this.velocidade = vel;
	}

	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}

	public void setX(int x) {
		this.x = x;		
	}
	
	public void setY(int y) {
		this.y = y;		
	}
}
