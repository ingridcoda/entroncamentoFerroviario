package state.sinalState;

import domain.Sinal;

public class Fechado extends SinalState {
	
	public void abrir(Sinal sinal) {
		sinal.setEstado(new Aberto());
	}

}
