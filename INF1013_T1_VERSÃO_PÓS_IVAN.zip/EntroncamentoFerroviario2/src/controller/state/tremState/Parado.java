package controller.state.tremState;

public class Parado extends TremState {

	public TremState timeout() {
		return null;
	}

	public void andar() {

	}

}
