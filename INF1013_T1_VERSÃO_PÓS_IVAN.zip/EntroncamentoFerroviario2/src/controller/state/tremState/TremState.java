package controller.state.tremState;

import domain.Trem;

public class TremState {

	private Trem trem;

	public TremState getEstadoInicial(Trem trem) {
		return null;
	}

	public String estado() {
		return null;
	}

	public TremState timeout() {
		return null;
	}

	public void parar() {

	}

	public void andar() {

	}

}
