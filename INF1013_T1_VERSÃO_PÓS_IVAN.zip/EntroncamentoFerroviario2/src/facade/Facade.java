package facade;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;

import domain.Sinal;
import domain.Trem;
import view.FerroviaFrame;

public class Facade {
	
	static ArrayList<Trem> trensD;
	static ArrayList<Trem> trensE;

	public static void Start() throws IOException {
		
		new FerroviaFrame();
		
	}
	
	public static Trem CriaTrem(String direcao){
		return new Trem(direcao);
	}

	public static void CriaTremEsquerda(ActionEvent event, ArrayList<Point> trensViewEsquerda) {
		
		trensE.add(Facade.CriaTrem("esquerda"));
		Point ponto = new Point(0, 333);
		trensViewEsquerda.add(ponto);		
		
	}
	
	public static void CriaTremDireita(ActionEvent event, ArrayList<Point> trensViewDireita) {
		
		trensD.add(Facade.CriaTrem("direita"));
		Point ponto = new Point(1540, 460);
		trensViewDireita.add(ponto);		
		
	}

	public static void CriaSinal(String direcao) {
		new Sinal(direcao);
	}

	public static String VerificaSinalEsquerda() {
		return null;
	}

}
