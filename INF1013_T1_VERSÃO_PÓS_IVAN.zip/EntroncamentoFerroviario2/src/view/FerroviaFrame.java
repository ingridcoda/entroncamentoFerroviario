package view;

import java.awt.Color;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;


import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;

import facade.Facade;

@SuppressWarnings("serial")

public class FerroviaFrame extends JFrame implements ActionListener{

	public static FerroviaFrame instancia = null;
	private ArrayList<Point> trensD;
	private ArrayList<Point> trensE;
	private JButton btnStartD;
	private JButton btnStartE;

	public FerroviaFrame() throws IOException {	
		
		super();
		this.setSize(1575, 787);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setBackground(Color.WHITE);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Entroncamento Ferrovi�rio");		

		this.trensD = new ArrayList<Point>();
		this.trensE = new ArrayList<Point>();
		
		this.btnStartD = new JButton("Trem � direita");
		this.btnStartD.setBounds(800, 700, 150, 40);
		this.btnStartD.setVisible(true);
		this.add(btnStartD);
		this.btnStartD.addActionListener(this);

		this.btnStartE = new JButton("Trem � esquerda");
		this.btnStartE.setBounds(610, 700, 150, 40);
		this.btnStartE.setVisible(true);
		this.add(btnStartE);
		this.btnStartE.addActionListener(this);
		
		this.getContentPane().add(new FerroviaView("Ferrovia.jpg"));
		this.setVisible(true);

	}

	public static FerroviaFrame getInstance() throws IOException {
		if(instancia == null){
			instancia = new FerroviaFrame();
		} 
		return instancia;
	}
	
	

	@Override
	public void actionPerformed(ActionEvent event) {
		
		if(event.getSource() == btnStartD) {
			
			Facade.CriaTremDireita(event, trensD);
			System.out.println("direita");

		} else if(event.getSource() == btnStartE){

			Facade.CriaTremEsquerda(event, trensE);
			System.out.println("esquerda");
			
		}	

	}  
}

