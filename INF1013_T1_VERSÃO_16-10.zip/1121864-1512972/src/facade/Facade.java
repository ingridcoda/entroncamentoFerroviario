package facade;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import domain.Ferrovia;
import domain.Sinal;
import domain.Trem;
import model.Matriz;
import view.FerroviaFrame;
import view.TelaCampoBatalha;


// TODO: CRIAR M�TODO DE DISPARO DE TRENS, COM L�GICA DE ESTADO DO SINAL E DO TREM.
public class Facade implements Observer{

	static ArrayList<Trem> trensD;
	static ArrayList<Trem> trensE;
	static Sinal sinalEsquerda;
	static Sinal sinalDireita;
	static Ferrovia f = new Ferrovia();

	public static void Start() throws IOException {

		new FerroviaFrame();
		trensE = new ArrayList<Trem>();
		trensD = new ArrayList<Trem>();
		sinalEsquerda = new Sinal("esquerda");
		sinalDireita = new Sinal("direita");

	}

	public static Trem CriaTrem(String direcao){

		return new Trem(direcao);

	}

	public static void CriaTremEsquerda(ActionEvent event, ArrayList<Point> trensViewEsquerda) {

		trensE.add(Facade.CriaTrem("esquerda"));
		Point ponto = new Point(0, 333);
		trensViewEsquerda.add(ponto);		

	}

	public static void CriaTremDireita(ActionEvent event, ArrayList<Point> trensViewDireita) {

		trensD.add(Facade.CriaTrem("direita"));
		Point ponto = new Point(1540, 460);
		trensViewDireita.add(ponto);		

	}

	public static void CriaSinal(String direcao) {
		new Sinal(direcao);
	}

	public static String VerificaSinalEsquerda() {

		System.out.println(sinalEsquerda.getEstado().getClass().getSimpleName());

		return sinalEsquerda.getEstado().getClass().getSimpleName();
	}

	public static String VerificaSinalDireita() {

		return null; //TODO: FAZER A VERIFICA��O DO SINAL STATE

	}

	public static ArrayList<Point> GetTrensEsquerda(){

		ArrayList<Point> trensViewsE = new ArrayList<Point>();

		for(Trem t : trensE) {
			trensViewsE.add(new Point(t.getX(), t.getY()));
		}

		return trensViewsE;
	}

	public static ArrayList<Point> GetTrensDireita(){

		ArrayList<Point> trensViewsD = new ArrayList<Point>();

		for(Trem t : trensD) {
			trensViewsD.add(new Point(t.getX(), t.getY()));
		}

		return trensViewsD;
	}

	public static void AlteraSinalDireita() {

		if(Facade.VerificaSinalDireita() == "fechado") {
			//abre sinal
		} else {
			//fecha sinal
		}

	}

	public static void AlteraSinalEsquerda() {

		if(Facade.VerificaSinalEsquerda() == "fechado") {
			//abre sinal
		} else {
			//fecha sinal
		}		

	}

	public static Point AtualizaTrem(Point p1, Point p2, String direcao) {

		Point p = null;
		if(direcao.equals("esquerda")) {

			for(Trem t : trensE) {
				if(t.getX() == p1.x && t.getY() == p1.y) {
					t.setX(p2.x);
					t.setY(p2.y);
					p = new Point(t.getX(), t.getY());
				}
			}

		} else {
			for(Trem t : trensD) {
				if(t.getX() == p1.x && t.getY() == p1.y) {
					t.setX(p2.x);
					t.setY(p2.y);
					p = new Point(t.getX(), t.getY());
				}
			}
		}
		return p;

	}

	public static void RemoveTrem(Point p, String direcao) {

		if(direcao.equals("esquerda")) {
			trensE.remove(trensE.get(0));
		} else {
			trensD.remove(trensD.get(0));
		}
	}

	@Override
	public void update(Observable o, Object arg) {
		/* verifica se observado mudou em algo */
		if(o.hasChanged()){
			System.out.println("O observador foi notificado de uma modifica��o!");
			Sinal s = (Sinal) arg;
			if(s.getDirecao().equals("esquerda")) {
				Facade.sinalEsquerda = s;
			} else {
				Facade.sinalDireita = s;
			}

		}
		
	}

	public static void EstaNoSensor(String acao, String direcao) {
		if(acao.equals("entrada")) {
			if(direcao.equals("esquerda")) {
				f.setSensorEntradaEsquerda();
				
			} else {
				f.setSensorSaidaEsquerda();
			}
		} else {
			if(direcao.equals("direita")) {
				f.setSensorEntradaDireita();
			} else {
				f.setSensorSaidaDireita();
			}
		}
		
	}
}
