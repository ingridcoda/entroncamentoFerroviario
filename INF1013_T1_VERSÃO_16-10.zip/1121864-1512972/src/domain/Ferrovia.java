package domain;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class Ferrovia extends Observable {
	
	private boolean sensorEntradaDireita;
	private boolean sensorSaidaDireita;
	private boolean sensorEntradaEsquerda;
	private boolean sensorSaidaEsquerda;
	public ArrayList<Observer> listaObserver = new ArrayList<Observer>();
	
	

	public Ferrovia() {
		super();
		this.sensorEntradaDireita = false;
		this.sensorSaidaDireita = false;
		this.sensorEntradaEsquerda = false;
		this.sensorSaidaEsquerda = false;
	}
	
	public void setSensorEntradaDireita() {
		this.sensorEntradaDireita = !sensorEntradaDireita;
		notifyObservers();
	}
	
	public void setSensorSaidaDireita() {
		this.sensorSaidaDireita = !sensorSaidaDireita;
		notifyObservers();
	}
	
	public void setSensorEntradaEsquerda() {
		this.sensorEntradaEsquerda = !sensorEntradaEsquerda;
		notifyObservers();
	}
	
	public void setSensorSaidaEsquerda() {
		this.sensorSaidaEsquerda = !sensorSaidaEsquerda;
		notifyObservers();
	}
	
	/* Observer */
	public void notifyObservers(Object obj){
		
		for(Observer obs: listaObserver){
			obs.update(this, obj);
		}
	}

}
