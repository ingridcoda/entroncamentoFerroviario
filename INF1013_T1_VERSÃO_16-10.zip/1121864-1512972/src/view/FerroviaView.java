package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.geom.Ellipse2D;
import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import facade.Facade;


@SuppressWarnings("serial")
public class FerroviaView extends JPanel implements Observer {

	private Image img = null;

	public FerroviaView(String urlImg) throws IOException    {  

		this.img = ImageIO.read(new File(urlImg)); 

		this.setLayout(null);
		this.setBounds(0, 0, 1575, 787);		

		Facade.CriaSinal("direita");
		Facade.CriaSinal("esquerda");

		this.setVisible(true);

	}

	@Override  
	public void paintComponent(Graphics g) {  

		super.paintComponent(g);        
		Graphics2D g2d = (Graphics2D)g;  
		System.out.println("Entrei no paint de ferroviaview");

		g2d.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), null);

		/* sinais */
		g2d.setColor(Color.BLACK);
		g2d.drawRect(1360, 530, 30, 30);
		g2d.fillRect(1360, 530, 30, 30);

		if(Facade.VerificaSinalDireita() == "fechado"){
			g2d.setColor(Color.RED);
		} else {
			g2d.setColor(Color.GREEN);
		}

		g2d.fill(new Ellipse2D.Double(1365, 535, 20, 20));

		g2d.setColor(Color.BLACK);
		g2d.drawRect(200, 260, 30, 30);
		g2d.fillRect(200, 260, 30, 30);

		if(Facade.VerificaSinalEsquerda() == "fechado"){
			g2d.setColor(Color.RED);
		} else {
			g2d.setColor(Color.GREEN);
		}
		g2d.fill(new Ellipse2D.Double(205, 265, 20, 20));



		for(Point p : Facade.GetTrensEsquerda()) {

			if(p == null) break;
			
			System.out.println(p);
			g2d.setColor(Color.BLACK);					
			g2d.draw(new Ellipse2D.Double(p.x, p.y, 30, 30));
			g2d.fill(new Ellipse2D.Double(p.x, p.y, 30, 30));

			if(p.x < 200 && p.y == 333) { // antes do sensor da entrada

				p = Facade.AtualizaTrem(p, new Point(p.x + 10, p.y), "esquerda");
				System.out.println("reta 1");

			} else if(p.x == 200 && p.y == 333) { // no sensor da entrada
				
				Facade.EstaNoSensor("entrada", "esquerda");

				if(Facade.VerificaSinalEsquerda().equals("Aberto")) {
					p = Facade.AtualizaTrem(p, new Point(p.x + 5, p.y + 1), "esquerda");
					Facade.AlteraSinalDireita();
					System.out.println("sensor 1");
				}

			} else if(p.x <= 440 && p.y <= 383) { // depois do sensor da entrada, indo pro meio

				if(p.y == 383) 
					p = Facade.AtualizaTrem(p, new Point(p.x + 5, p.y), "esquerda");
			    else if(p.x == 440)
					p = Facade.AtualizaTrem(p, new Point(p.x, p.y + 1), "esquerda");
				else
					p = Facade.AtualizaTrem(p, new Point(p.x + 5, p.y + 1), "esquerda");
				System.out.println("curva 1");


			} else if(p.x <= 1150 && p.y == 383) { // meio

				if(p.x == 1150)
					p = Facade.AtualizaTrem(p, new Point(p.x + 5, p.y - 2), "esquerda");
				else
					p = Facade.AtualizaTrem(p, new Point(p.x + 5, p.y), "esquerda"); 
				System.out.println("meio");


			} else if(p.x < 1370 && p.y >= 338) { // depois do meio, indo pro sensor da saida

				if(p.y == 338) {
					p = Facade.AtualizaTrem(p, new Point(p.x + 5, p.y), "esquerda");
				} else
					p = Facade.AtualizaTrem(p, new Point(p.x + 5, p.y - 1), "esquerda");
				System.out.println("curva 2");

			} else if(p.x >= 1370 && p.y == 338) { // no sensor da saida

				System.out.println("reta 2");
				
				Facade.EstaNoSensor("saida", "esquerda");
				
				p = Facade.AtualizaTrem(p, new Point(p.x + 10, p.y), "esquerda");
				if(p.x == 1570) {
					System.out.println("saiu");
					Facade.RemoveTrem(p, "esquerda");
				}

			}

		}		

		for(Point p : Facade.GetTrensDireita()){

			if(p == null) break;
			
			System.out.println(p);
			g2d.setColor(Color.RED);					
			g2d.draw(new Ellipse2D.Double(p.x, p.y, 30, 30));
			g2d.fill(new Ellipse2D.Double(p.x, p.y, 30, 30));

			if(p.x > 1360 && p.y == 460) { // antes do sensor da entrada

				p = Facade.AtualizaTrem(p, new Point(p.x - 10, p.y), "direita");
				System.out.println("reta 1");

			} else if(p.x == 1360 && p.y == 460) { // no sensor da entrada
				
				Facade.EstaNoSensor("entrada", "direita");

				if(Facade.VerificaSinalEsquerda().equals("Aberto")) {
					p = Facade.AtualizaTrem(p, new Point(p.x - 5, p.y - 2), "direita");
					Facade.AlteraSinalEsquerda();
					System.out.println("sensor 1");
				} 

			} else if(p.x >= 1150 && p.y >= 383) { // depois do sensor da entrada, indo pro meio

				if(p.y == 383) 
					p = Facade.AtualizaTrem(p, new Point(p.x - 5, p.y), "direita");
			    else if(p.x == 1150)
					p = Facade.AtualizaTrem(p, new Point(p.x, p.y - 2), "direita");
				else
					p = Facade.AtualizaTrem(p, new Point(p.x - 5, p.y - 2), "direita");
				System.out.println("curva 1");


			} else if(p.x >= 440 && p.y == 383) { // meio

				if(p.x == 440)
					p = Facade.AtualizaTrem(p, new Point(p.x - 5, p.y + 2), "direita");
				else
					p = Facade.AtualizaTrem(p, new Point(p.x - 5, p.y), "direita"); 
				System.out.println("meio");


			} else if(p.x > 195 && p.y <= 460) { // depois do meio, indo pro sensor da saida

				if(p.y == 460) {
					p = Facade.AtualizaTrem(p, new Point(p.x - 5, p.y), "direita");
				} else
					p = Facade.AtualizaTrem(p, new Point(p.x - 10, p.y + 3), "direita");
				System.out.println("curva 2");

			} else if(p.x <= 195 && p.y == 457) { // no sensor da saida

				System.out.println("reta 2");
				
				Facade.EstaNoSensor("saida", "direita");
				
				p = Facade.AtualizaTrem(p, new Point(p.x - 10, p.y), "direita");
				if(p.x <= 0) {
					System.out.println("saiu");
					Facade.RemoveTrem(p, "direita");
				}

			}
		}

	}

	@Override
	public void update(Observable arg0, Object arg1) {
		// TODO Auto-generated method stub

	}



}
