package controller;

import domain.Sinal;

//TODO: VER SE AINDA � NECESS�RIA ESSA CLASSE
public class SinalController {
	
	Sinal sinal;

	public SinalController(Sinal sv) {
		this.sinal = sv;
	}
	
	public void setEstadoAberto(){
		this.sinal.getEstado().abrir(sinal);
	}
	
	public void setEstadoFechado(){
		this.sinal.getEstado().abrir(sinal);
	}
}
