package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import facade.Facade;


@SuppressWarnings("serial")
public class FerroviaView extends JPanel {

	private Image img = null;
	Timer timer = new Timer(0, null);

	public FerroviaView(String urlImg) throws IOException    {  

		this.img = ImageIO.read(new File(urlImg)); 

		this.setLayout(null);
		this.setBounds(0, 0, 1575, 787);		

		Facade.CriaSinal("direita");
		Facade.CriaSinal("esquerda");

		this.setVisible(true);

	}

	@Override  
	public void paintComponent(Graphics g) {  

		super.paintComponent(g);        
		Graphics2D g2d = (Graphics2D)g;  
		System.out.println("Entrei no paint de ferrovia");
		g2d.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), null);

		/* sinais */
		g2d.setColor(Color.BLACK);
		g2d.drawRect(1360, 530, 30, 30);
		g2d.fillRect(1360, 530, 30, 30);

		if(Facade.VerificaSinalDireita() == "fechado"){
			g2d.setColor(Color.RED);
		} else {
			g2d.setColor(Color.GREEN);
		}

		g2d.fill(new Ellipse2D.Double(1365, 535, 20, 20));

		g2d.setColor(Color.BLACK);
		g2d.drawRect(200, 260, 30, 30);
		g2d.fillRect(200, 260, 30, 30);

		if(Facade.VerificaSinalEsquerda() == "fechado"){
			g2d.setColor(Color.RED);
		} else {
			g2d.setColor(Color.GREEN);
		}
		g2d.fill(new Ellipse2D.Double(205, 265, 20, 20));

		timer = new Timer(1000, new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {

				for(Point p : Facade.GetTrensEsquerda()) {
					
					if(p == null) break;					
					
					
					if(p.x < 200 && p.y == 333) { // antes do sensor da entrada
						
						p.setLocation(p.x + 10, p.y);
						
					} else if(p.x == 200 && p.y == 333) { // no sensor da entrada

						if(Facade.VerificaSinalEsquerda() == "aberto") {
							p.setLocation(p.getX() + 4.8, p.getX() + 4.8);
							Facade.AlteraSinalDireita();
						}

					} else if(p.x < 440 && p.y < 383) { // depois do sensor da entrada, indo pro meio

						p.setLocation(p.x + 2, p.y + 2);
						

					} else if(p.x < 1150 && p.y == 383) { // inicio do meio
						
						if(p.x == 440) {
							
						}
						

					} else if(p.x == 1150 & p.y == 383) { // final do meio
						
						
						
					} else if(p.x < 1370 && p.y > 337) { // depois do meio, indo pro sensor da saida
						
						
						
					} else if(p.x >= 1370 && p.y == 337) { // no sensor da saida
						
						
						
					}
					
					g2d.setColor(Color.BLACK);					
					g2d.fill(new Ellipse2D.Double(p.x, p.y, 30, 30));
				}

				for(Point p : Facade.GetTrensDireita()){
					
					if(p == null) break;								
					
					if(p.x > 1360 && p.y == 460) { // antes do sensor da entrada
						
						p.setLocation(p.x - 10, p.y);
						
					} else if(p.x == 1360 && p.y == 460) { // no sensor da entrada

						if(Facade.VerificaSinalDireita() == "aberto") {
							p.setLocation(p.getX() + 2.73, p.getX() + 2.73);
							Facade.AlteraSinalEsquerda();
						}

					} else if(p.x > 1150 && p.y > 383) { // depois do sensor da entrada, indo pro meio

						p.setLocation(p.x + 2, p.y + 2);
						

					} else if(p.x > 440 && p.y == 383) { // inicio do meio
						
						if(p.x == 1150) {
							
						}
						

					} else if(p.x == 440 & p.y == 383) { // final do meio
						
						
						
					} else if(p.x > 195 && p.y < 460) { // depois do meio, indo pro sensor da saida
						
						
						
					} else if(p.x <= 195 && p.y == 460) { // no sensor da saida
						
						
						
					}
					
					g2d.setColor(Color.RED);
					g2d.fill(new Ellipse2D.Double(p.x, p.y, 30, 30));
				}
			}

		});

		timer.start();







	}



}
