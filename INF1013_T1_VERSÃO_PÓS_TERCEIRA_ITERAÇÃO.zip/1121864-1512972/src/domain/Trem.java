package domain;

import controller.state.tremState.Parado;
import controller.state.tremState.TremState;

public class Trem {

	private String direcao;
	
	private int x, y;

	private float velocidade;

	private TremState estado;

	public Trem (String dir) {
		
		this.direcao = dir;
		
		if (this.direcao.equals("esquerda")) {			
			this.velocidade = 5;			
		} else {			
			this.velocidade = -5;			
		}
		
		this.estado = new Parado();

	}


	public String getDirecao() {
		return direcao;
	}

	public void setDirecao(String dir) {
		this.direcao = dir;
	}

	public TremState getEstado() {
		return estado;
	}

	public void setEstado(TremState est) {
		this.estado = est;
	}

	public float getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(float vel) {
		this.velocidade = vel;
	}

	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
}
