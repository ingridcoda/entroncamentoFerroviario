package facade;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;

import domain.Sinal;
import domain.Trem;
import view.FerroviaFrame;


// TODO: CRIAR M�TODO DE DISPARO DE TRENS, COM L�GICA DE ESTADO DO SINAL E DO TREM.
public class Facade {
	
	static ArrayList<Trem> trensD;
	static ArrayList<Trem> trensE;

	public static void Start() throws IOException {
		
		new FerroviaFrame();
		trensE = new ArrayList<Trem>();
		trensD = new ArrayList<Trem>();
		
	}
	
	public static Trem CriaTrem(String direcao){
		
		return new Trem(direcao);
		
	}

	public static void CriaTremEsquerda(ActionEvent event, ArrayList<Point> trensViewEsquerda) {
		
		trensE.add(Facade.CriaTrem("esquerda"));
		Point ponto = new Point(0, 333);
		trensViewEsquerda.add(ponto);		
		
	}
	
	public static void CriaTremDireita(ActionEvent event, ArrayList<Point> trensViewDireita) {
		
		trensD.add(Facade.CriaTrem("direita"));
		Point ponto = new Point(1540, 460);
		trensViewDireita.add(ponto);		
		
	}

	public static void CriaSinal(String direcao) {
		new Sinal(direcao);
	}

	public static String VerificaSinalEsquerda() {
		
		return null; //TODO: FAZER A VERIFICA��O DO SINAL STATE
		
	}
	
	public static String VerificaSinalDireita() {
		
		return null; //TODO: FAZER A VERIFICA��O DO SINAL STATE
		
	}
	
	public static ArrayList<Point> GetTrensEsquerda(){
		
		ArrayList<Point> trensViewsE = new ArrayList<Point>();
		
		for(Trem t : trensE) {
			trensViewsE.add(new Point(t.getX(), t.getY()));
		}
		
		return trensViewsE;
	}
	
	public static ArrayList<Point> GetTrensDireita(){
		
		ArrayList<Point> trensViewsD = new ArrayList<Point>();
		
		for(Trem t : trensD) {
			trensViewsD.add(new Point(t.getX(), t.getY()));
		}
		
		return trensViewsD;
	}

	public static void AlteraSinalDireita() {
		
		if(Facade.VerificaSinalDireita() == "fechado") {
			//abre sinal
		} else {
			//fecha sinal
		}
		
	}

	public static void AlteraSinalEsquerda() {
		
		if(Facade.VerificaSinalEsquerda() == "fechado") {
			//abre sinal
		} else {
			//fecha sinal
		}		
		
	}
}
