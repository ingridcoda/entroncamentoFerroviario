package controller;

import java.awt.Point;
import java.util.ArrayList;

import javax.swing.Timer;

//TODO: VER SE AINDA � NECESS�RIA ESSA CLASSE
public class TremController {

	Timer timer = new Timer(0, null);
	ArrayList<Point> trens = new ArrayList<Point>();

	public TremController(ArrayList<Point> t){
		this.trens = t;
	}
}
