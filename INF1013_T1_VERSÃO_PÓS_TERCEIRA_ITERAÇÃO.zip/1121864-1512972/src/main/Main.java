package main;

import java.io.IOException;

import facade.Facade;

public class Main {
	
	public static void main(String[] args) throws IOException {
		Facade.Start();
	}

}
