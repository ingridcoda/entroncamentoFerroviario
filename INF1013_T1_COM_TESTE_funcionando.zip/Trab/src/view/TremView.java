package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import controller.TremController;
import domain.Trem;

public class TremView extends JPanel {
	private Trem tremModel;
	private int x;
	private int y;
	private Color cor;
	
	
	public TremView(Trem trem, Color cor, int x, int y) {
		tremModel = trem;
		this.x = x;
		this.y = y;
		this.cor = cor;
		this.setLayout(null);
		this.setBounds(0, 0, 30, 30);
	    this.setBackground(this.cor);
		this.setLocation(this.x, this.y);		
		this.setVisible(true);
		System.out.println("Entrei no construtor de trem");
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(cor);
		g2d.drawOval(x, y, 30, 30);		
		g2d.fillOval(x, y, 30, 30);
		System.out.println("Entrei no paint de trem");
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Color getCor() {
		return cor;
	}

	public void setCor(Color cor) {
		this.cor = cor;
	}
	
	public Trem getModel(){
		return tremModel;
	}
}
