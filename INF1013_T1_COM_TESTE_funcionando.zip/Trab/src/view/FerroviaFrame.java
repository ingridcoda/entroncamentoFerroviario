package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;


import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;

import facade.Facade;

@SuppressWarnings("serial")

public class FerroviaFrame extends JFrame implements ActionListener{

	public static FerroviaFrame instancia = null;
	private JButton btnStartD;
	private JButton btnStartE;
	private ArrayList<TremView> trensD;
	private ArrayList<TremView> trensE;
	private TremView trem;
	private SinalView sinalDireita;
	private SinalView sinalEsquerda;
	Timer time;

	public FerroviaFrame() throws IOException {	
		
		super();
		this.setSize(1575, 787);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setBackground(Color.WHITE);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Entroncamento Ferrovi�rio");	
		


		this.btnStartD = new JButton("Trem � direita");
		this.btnStartD.setBounds(800, 700, 150, 40);
		this.btnStartD.setVisible(true);
		this.add(btnStartD);
		this.btnStartD.addActionListener(this);

		this.btnStartE = new JButton("Trem � esquerda");
		this.btnStartE.setBounds(610, 700, 150, 40);
		this.btnStartE.setVisible(true);
		this.add(btnStartE);
		this.btnStartE.addActionListener(this);

		this.trensD = new ArrayList<TremView>();
		this.trensE = new ArrayList<TremView>();
		
		this.sinalDireita = new SinalView(Facade.CriaSinalModel("direita"),Color.GREEN, 1360, 530);;
		this.getContentPane().add(sinalDireita);
		this.sinalEsquerda = new SinalView(Facade.CriaSinalModel("esquerda"),Color.GREEN, 200, 260);
		this.getContentPane().add(sinalEsquerda);
		//this.getContentPane().add(new FerroviaView("Ferrovia.jpg"));
		this.setVisible(true);

	}

	public static FerroviaFrame getInstance() throws IOException {
		if(instancia == null){
			instancia = new FerroviaFrame();
		} 
		return instancia;
	}
	
	

	@Override
	public void actionPerformed(ActionEvent event) {
		
		if(event.getSource() == btnStartD) {
			
			trem = new TremView(Facade.CriaTremModel("direita"), Color.RED, 1540, 460);
			Facade.CriaTremController(trem);
			this.getContentPane().add(trem);
			this.trensD.add(trem);

			Facade.IniciaTrem(event, trensD);
			System.out.println("direita");

		} else if(event.getSource() == btnStartE){

			trem = new TremView(Facade.CriaTremModel("esquerda"), Color.BLUE, 0, 333);
			Facade.CriaTremController(trem);
			this.getContentPane().add(trem);
			this.trensE.add(trem);	
			
			Facade.IniciaTrem(event, trensE);
			System.out.println("esquerda");
		}	

	}  
}

