package facade;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;

import controller.FerroviaController;
import controller.SinalController;
import controller.TremController;
import domain.Sinal;
import domain.Trem;
import view.FerroviaFrame;
import view.SinalView;
import view.TremView;

public class Facade {

	public static void Start() throws IOException {
		
		new FerroviaFrame();
		
	}
	
	public static Trem CriaTremModel(String direcao){
		return new Trem(direcao);
	}
	
	public static TremController CriaTremController(TremView tv){
		return new TremController(tv);
	}

	public static void IniciaTrem(ActionEvent event, ArrayList<TremView> trens) {
		
		FerroviaController.getInstance(trens).actionPerformed(event);
		
	}

	public static Sinal CriaSinalModel(String direcao) {
		return new Sinal(direcao);
	}
	
	public static SinalController CriaSinalController(SinalView sv){
		return new SinalController(sv);
	}

}
