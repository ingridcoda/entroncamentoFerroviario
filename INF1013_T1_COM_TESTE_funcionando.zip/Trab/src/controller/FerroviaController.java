package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Timer;

import domain.Ferrovia;
import view.TremView;

public class FerroviaController implements ActionListener{

	Ferrovia ferrovia;
	Timer timer = new Timer(0, null);
	static ArrayList<TremView> trens = new ArrayList<TremView>();
	static int passo;
	public static FerroviaController instancia = null;

	public static FerroviaController getInstance(ArrayList<TremView> trens){
		if(instancia == null){
			instancia = new FerroviaController(trens);
		}
		setValues(trens);
		return instancia;
	}

	public FerroviaController(ArrayList<TremView> trens) {
		FerroviaController.trens = trens;
	}

	public static void setValues(ArrayList<TremView> trens){
		FerroviaController.trens = trens;
	}

	@Override
	public void actionPerformed(ActionEvent event) {

		for(TremView t : trens) {
			new TremController(t).actionPerformed(event);
		}		
	}

}


