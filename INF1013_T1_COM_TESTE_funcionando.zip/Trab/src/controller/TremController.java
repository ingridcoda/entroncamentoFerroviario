package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

import view.TremView;

public class TremController implements ActionListener{
	
	Timer timer = new Timer(0,null);
	TremView trem;
	
	public TremController(TremView t){
		this.trem = t;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		timer = new Timer(1000, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				int p = (int) (trem.getX() + trem.getModel().getVelocidade());
				trem.setX(p);
				trem.setLocation(trem.getX(), trem.getY());

				System.out.println("Trem " + trem.getCor()+ " local " +trem.getLocation());
				trem.repaint();
			}

		});
		timer.start();		
	}
}
