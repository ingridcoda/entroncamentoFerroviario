package controller;

import view.SinalView;

public class SinalController {
	
	SinalView sinal;

	public SinalController(SinalView sv) {
		this.sinal = sv;
	}
	
	public void setEstadoAberto(){
		this.sinal.getModel().getEstado().abrir(sinal.getModel());
	}
	
	public void setEstadoFechado(){
		this.sinal.getModel().getEstado().fechar(sinal.getModel());
	}
}
