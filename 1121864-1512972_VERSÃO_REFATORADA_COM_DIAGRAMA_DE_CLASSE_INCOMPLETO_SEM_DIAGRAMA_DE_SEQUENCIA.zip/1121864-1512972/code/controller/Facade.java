package controller;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;

import domain.Ferrovia;
import view.FerroviaFrame;
import view.FerroviaView;


public class Facade {

	public static Facade instancia = null;
	private static Ferrovia f;

	private Facade() throws IOException {		
		f = Ferrovia.getInstance();
		f.getListaObserver().add(FerroviaView.getInstance("Ferrovia.jpg"));
		FerroviaFrame.getInstance();			
	}
	
	
	///////////////////////// Singleton ///////////////////////////
	public static Facade getInstance() throws IOException {		
		if(instancia == null){
			instancia = new Facade();
		}
		
		return instancia;		
	}
	//////////////////////////////////////////////////////////////	
	
	
	public static void CriaTremEsquerda(ActionEvent event, ArrayList<Point> trensViewEsquerda) {
		f.CriaTremEsquerda(event, trensViewEsquerda);		
	}

	public static void CriaTremDireita(ActionEvent event, ArrayList<Point> trensViewDireita) {		
		f.CriaTremDireita(event, trensViewDireita);	
	}

	public static void CriaSinal(String direcao) {		
		f.CriaSinal(direcao);			
	}

	public static String VerificaSinalEsquerda() {		
		return f.VerificaSinalEsquerda();		
	}

	public static String VerificaSinalDireita() {		
		return f.VerificaSinalDireita();	
	}

	public static ArrayList<Point> GetTrensEsquerda() {
		return f.GetTrensEsquerda();
	}

	public static ArrayList<Point> GetTrensDireita() {
		return f.GetTrensDireita();	
	}

	public static void AlteraSinalEsquerda() {
		f.AlteraSinalEsquerda();
	}
	
	public static void AlteraSinalDireita() {
		f.AlteraSinalDireita();
	}
	
	public static boolean DistanciaMinima(Point p1, Point p2, String direcao) {
		return f.DistanciaMinima(p1, p2, direcao);
	}

	public static Point AtualizaTrem(Point p1, Point p2, String direcao) {
		return f.AtualizaTrem(p1, p2, direcao);
	}

	public static void RemoveTrem(Point p, String direcao) {
		f.RemoveTrem(p, direcao);
	}

	public static void EstaNoSensor(String acao, String direcao) {		
		f.EstaNoSensor(acao, direcao);
	}

	
}
