package main;

import java.io.IOException;

import controller.Facade;

public class Main {
	
	public static void main(String[] args) throws IOException {
		Facade.getInstance();
	}

}
